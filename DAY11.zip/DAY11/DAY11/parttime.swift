//
//  parttime.swift
//  DAY11
//
//  Created by MacStudent on 2018-02-12.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class parttime : student
{
    var sname: String?
    
    fileprivate func setrstudentname(sname: String)
    {
        self.sname = sname
    }
}

internal class extendparttime: parttime
{
    override internal func setrstudentname(sname: String)
    {
       super.setrstudentname(sname: sname)
    }
}
