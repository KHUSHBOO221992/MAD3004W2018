//
//  main.swift
//  DAY11
//
//  Created by MacStudent on 2018-02-12.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

var objstud = student()
objstud.display()
//objstud.


var objextpt = extendparttime()

