//
//  student.swift
//  DAY11
//
//  Created by MacStudent on 2018-02-12.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

private class teststud : student{
    
}

class student
{
    private var sname: String?
    
    init()
    {
        self.sname = "STUDENT NAME"
    }
    
    func setstudentname(sname: String)
    {
        self.sname = sname
    }
    
    func getstudentname() -> String
    {
        return self.sname!
    }
    
    func display()
    {
        print(" I AM PRIVATE METHOD OF STUDENT CLASS")
    }
    fileprivate func display(message: String)
    {
        print("HELLO \(message)")
    }
}



