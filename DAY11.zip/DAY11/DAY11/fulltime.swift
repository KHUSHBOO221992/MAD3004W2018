//
//  fulltime.swift
//  DAY11
//
//  Created by MacStudent on 2018-02-12.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

private class fulltime: student
{
    var subject: String?
    
    override init()
    {
        self.subject = "FULLTIME STUDENT"
    }
    
    private func setsubject(subject: String)
    {
        self.subject = subject
    }
    
    override func display()
    {
        print(" I AM METHOD OF FULLTIME CLASS")
        super.display(message: "FILE PRIVATE")
    }
}
