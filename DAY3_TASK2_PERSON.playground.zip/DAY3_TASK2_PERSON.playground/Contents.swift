//: Playground - noun: a place where people can play

import UIKit

var Person = [String : AnyObject]()
Person["       First Name"] = "KB" as AnyObject
Person["       Last Name"] = "BHATOIA" as AnyObject
Person["       Age"] = Int(25) as AnyObject
Person["       Total Amount"] = Int(2000) as AnyObject
print("PERSON:")
for(p,q) in Person
{
    print("\(p) -> \(q)")
}


var Address = [String : AnyObject]()
Address["      Street"] = "265 Yorkland Blvd" as AnyObject
Address["      Area"] = "North York" as AnyObject
Address["      Postal Code"] = "M1H1Y1" as AnyObject
print("ADDRESS:")
for(c,d) in Address
{
    print("\(c) -> \(d)")
}




