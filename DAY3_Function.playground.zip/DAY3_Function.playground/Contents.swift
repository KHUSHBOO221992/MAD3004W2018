//: Playground - noun: a place where people can play

import UIKit

// simple declaration
func add()
{
    print("I AM AN IN BUILT FUNCTIOM.")
}

add()

func add(n1:Int, n2:Int)
{
    var sum: Int
    sum = n1 + n2
    print("SUM:", sum)
}

add(n1:10,n2:20)

//add(n2:30,n1:40)            //ERROR- ACCORDING TO THE PARAMETER N1 SHOULD BE FIRST
//add(10,20)                  //ERROR-MISSING ARGUMENT


//MAKING PARAMETER LABEL OPTIONAL USING
func sub(a:Int, _ b:Int)
{
    
    let c = a - b
    print("SUB: \(c)")
}
sub(a: 30, 20)

//SINGLE RETURN TYPE
func mult(a:Int, b:Int) -> Int
{
    
    let c = a * b
    return c
}

var c = mult(a: 2, b: 5)
print("MULT: \(c)")

//MULTI RETURN VALUES AND DEFINE NEW LABEL NAME
func swipe(num a: Int, b:Int) -> (Int,Int)
{
    //function parameter are constant by default
    //var temp = a
    //a = b
    //b = temp
    return(b,a)
}

var (a,b) = swipe(num: 10, b: 20)
print("A: \(a), B: \(b)")
(_, c) = swipe(num: 10, b: 20)
print("C: \(c)")


//INPUT CONCEPT
func swipe(aa: inout Double, bb: inout Double)
{
    let temp = aa
    aa = bb
    bb = temp
}

var x = 8.0, y = 9.0
swipe(aa:&x, bb:&y)
//swipe(aa:&10, bb:&20)                                 //LET VALUE CANNOT MODIFY
print("X: \(x),Y: \(y)")

//DEFAULT PARAMETER
func simpint(amt:Double, noofyr:Double, rate:Double = 5.0) -> Double
{
    let si = amt * rate * noofyr / 100
    return si
}

print("SIMPLE INTEREST : \(simpint(amt: 1000, noofyr: 5))")
print("SIMPLE INTEREST : \(simpint(amt: 1000, noofyr: 5, rate: 10))")

func si(amt:Double,_ noofyr:Double, rate:Double) -> Double
{
    let si = amt * rate * noofyr / 100
    return si
}

print("SIMPLE INTEREST : \(simpint(amt: 1000, noofyr: 5))")
print("SIMPLE INTEREST : \(simpint(amt: 1000, noofyr: 5, rate: 10))")

//VARIADIC PARAMETERS
func display(n:Int...)
{
    for i in n{
        print(i)
    }
}

display(n: 1,2,3,4,5)
display(n: 10,20,30)


//PASSING ARRAY AS PARAMETER
func display(numval:Int, parameters:[Int]...)
{
    print("NUMBER OF VALUES: \(numval)")
    for i in parameters{
        print("I: \(i)")
    }
}

var arr = [1,2,3,4,5]
display(numval:3, parameters: arr,arr,arr)


//SUM OF TWO ARRAY
func display(arlist:[Int]...) -> [Int]
{
    var arr1 = arlist[0]
    var arr2 = arlist[1]
    var result = [Int]()
    
    if arr1.count == arr2.count{
        for i in 0..<arr1.count
        {
            result.append(arr1[i] + arr2[i])
        }
    }
    return result
}
var a1 = [1,2,3,4,5]
var a2 = [10,11,12,13,14]
var a3 = display(arlist:a1,a2)
print(a1)
print(a2)
print(a3)
























//SINGLE PARAMETER

func welcome(name:String)
{
    print("hello \(name)")
}


