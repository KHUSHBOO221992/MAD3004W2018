//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground";

print(str)
print("This is my area: \(str)",terminator: " ")


//use separator for separating multiple prompts
print("1","2","3","4","5",separator: "..")

print("hi","how are you?",separator: "..")

print("a","b","c",separator: "\n")

var n1 = 10
print("Number 1 : ",n1,"string : " , str)

var n2 = 20
print("number 2 : ",n2)

var sum = n1 + n2
print("sum is : ", sum)
print ("sum = ", n1 + n2)

/*
n1 = "test"
print("n1 : ",n1)
*/

var a: Int = 10
print("a = ",a)

var greet:String = "Good Morning"
print("Greetings : ",greet)

var b: Float = 23.65
print("b = ",b)

var emoji = " 😃";
print ("lolz \(emoji)")

//let is a constant,cant change value when already assigned
let pi = 3.14

print("Pi = ",pi)

//var pi = 10

let mynum:Int?  //optional
mynum = 10

if mynum != nil {
    print("mynum : ",mynum!)
}
else
{
    print("mynum is null")
}

//optional values IF TAKE FLOAT VALUE BUT TRY TO PRINT IN INT

let possiblenum = "HELLO"  //"hello"
let convertednum:Int?

convertednum = Int(possiblenum)

if convertednum != nil {
    print("Converted Number is:" ,convertednum!)
}
else{
    print("Coverted Number is Nil")
}

//for loop
for i in 1...5{
    print ("i =",i)
}

for i in 1..<5{
    print ("i =",i)
}

//PRINT AN ARRAY OF STRING
let lang:[String]
lang = ["ENG","SPANISH","FRENCH"]

for i in lang{
    print("LANGUAGE :", i)
}

let k1:[Int]
k1 = [1,2,3,4,5,6,7,8,9]

for i in k1{
    print(i,terminator: " " )
}

let k2:[Int]


k2 = [1,2,3,4,5,6,7,8,9]

for i in k2{
    print("Number :",i )
}

var ans: Int = 1
for _ in 1...5{
    ans *= 5;
}

/*
var interval:Int = 5
for i in stride(from: 0, to: 50 , by: interval) {
    print(i," ",terminator: " ")
    }
 */



var j = 1
while (j < 5)
{
    print( "value of j is \(j)")
    j = j + 1
}

j = 5
repeat{
    print("repeat : ",j)
    j = j + 2
} while (j<=10)


//switch
var num1 = 100
    switch num1 {
    case 100:
        print("VALUE IS NUMBER : 100")
        
    case 10,15:
        print("VALUE IS NUMBER : 10 OR 15")
        default:
        print("default case")
    }

//if value is less than 10 display table of 5 else display factorial of five
