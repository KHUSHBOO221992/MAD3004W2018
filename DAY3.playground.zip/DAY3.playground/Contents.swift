//: Playground - noun: a place where people can play

import UIKit

// DICTIONARIES

var str = [Int: String]()           //NAME OF THE INTEGER IS AN EMPTY DICTIONARY OF TYPE [Int : String] HERE
print("Name of Integer : \(str)")

str[28] = "TWENTY EIGHT"
print("Dictionary Contains \(str.count) Elements.")
print("Dictionary :",str)

str = [:]                                //NAMEOF DICTIONARY IS AN EMPTY DICTIONARY OF[:] TYPE [int :string]
print("Dictionary Contains \(str.count) Elements.")
print("Dictionary :",str)

if str.isEmpty {
    print("Dictionary is Empty")
}
else {
    print(str)
}



// TRY TO USE THREE OR MORE INTEGERS IN DICTIONARIES

var airports :[String: String] = ["YYZ": "TORONTO PEARSON", "DUB": "DUBLIN"]
print("AIRPORTS : \(airports)")
print("THE AIRPORT DICTIONARY CONTAIN \(airports.count) ITEMS.")   //PRINT DICTIONARY CONTAINS 2 ITEMS

airports["LHR"] = "LONDON HEATHROW"          // THE VALUE OF "LHR" HAS BEEN CHANGED TO "LONDON HEATHROW"
airports["YYZ"] = "TP INTERNATIONAL"
airports["AMD"] = "SVP INTERNATIONAL"
print("AIRPORTS : \(airports)")

let oldvalue = airports.updateValue("DUBLIN AIRPORT", forKey: "DUB")

print("THE OLD VALUE FOR DUB WAS \(oldvalue).")      //WARNING:IF OLDVALUE DOESN'T HAVE VALUE DUB U CAN USE NIL

if let airportname = airports["AMD"]
{
    print("THE NAME OF THE AIRPORT IS \(airportname).")
}
else
{
    print("THAT AIRPORT IS NOT IN THE AIRPORT DICTIONARY.")
}

airports["MARS"] = "RANGE ROVER"
print(airports)
airports["MARS"] = nil
print("AIRPORTS : \(airports)")

if let removedvalue = airports.removeValue(forKey: "DUB")
{
        print("THE REMOVED AIRPORT NAME IS \(removedvalue).")
}
else
{
        print("THE AIRPORTS DICTIONARY DOES NOT CINTAIN A VALUE FOR DUB.")
}


for(airportcode, airportname) in airports
{
    print(airportcode, airportname)
}

for airportcode in airports.keys
{
    print("AIRPORT CODE :\(airportcode)")
}

for airportname in airports.values
{
    print("AIRPORT NAME :\(airportname)")
}


let airportcodes = [String](airports.keys)         //AIRPORTCODES IS ["YYZ","LHR"]
print("AIRPORT CODE :\(airportcodes)")

let airportnames = [String](airports.values)         //AIRPORTCODES IS ["TORONTO PEARSON","LONDON HEATHROW"]
print("AIRPORT NAME :\(airportnames)")



//<KEY , VALUE > PAIRS

var d1 : Dictionary<String, String> = ["India":"Hindi", "Canada":"English"]
print(d1)
print(d1.description)
print(d1["India"]!)
print(d1["Canada"]!)
print(d1["USA"])
d1["China"] = "Mandarin"
for(k,v) in d1
{
    print("\(k) -> \(v)")
}

d1["Canada"] = "French"
for(k,v) in d1
{
    print("\(k) -> \(v)")
}


var d2 = ["India":"Hindi", "Canada":"English"]
for(k,v) in d2
{
    print("\(k) -> \(v)")
}

//DICTINARIES WITH ANY VALUES TYPE
var d3 = [String : AnyObject]()
d3["Fname"] = "KB" as AnyObject
d3["Lname"] = "BHATOIA" as AnyObject
d3["AGE"] = Int(25) as AnyObject
d3["Salary"] = nil
print("D3",d3)


//GETTING AS A KEY , VALUE PAIR
for(k,v) in d3
{
    print("\(k) -> \(v)")
}


// DECLARING TUPLES
var x = (10,20, "BHATOIA")
print(x.0)
print(x.1)
print(x.2)

let http404error = (404, "NOT FOUND")
print(http404error)

let(statuscode, statusmsz) = http404error
print("STATUSCODE:" ,statuscode)
print("STATUSMESSAGE:" ,statusmsz)

let(codeonly, _) = http404error
print("CODEONLY:", codeonly)

let errordesc = (code: 404, msz: "NOT FOUND")
print(errordesc.code, errordesc.msz)


































